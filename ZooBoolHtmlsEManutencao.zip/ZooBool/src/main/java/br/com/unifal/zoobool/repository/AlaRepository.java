package br.com.unifal.zoobool.repository;

import br.com.unifal.zoobool.entity.Ala;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AlaRepository extends JpaRepository<Ala, Integer> {
}
