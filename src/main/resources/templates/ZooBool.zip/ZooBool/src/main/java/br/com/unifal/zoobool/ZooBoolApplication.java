package br.com.unifal.zoobool;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZooBoolApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZooBoolApplication.class, args);
	}

}
