package br.com.unifal.zoobool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZooBoolApplicationTests {

	@Test
	void contextLoads() {
	}

}
